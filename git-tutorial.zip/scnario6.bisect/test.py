import doctest


def add(*args):
    """
    >>> add(1, 2, 3)
    6
    >>> add(1, 2, 3, 4)
    10
    >>> add(0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1)
    1
    """
    return sum(args)


result = doctest.testmod()
print(result)
